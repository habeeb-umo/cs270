#define HELLO_STR "Hello"

void printHello();