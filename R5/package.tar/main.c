#include <stdio.h>
#include "hello.h"
#include "world.h"

int main() {
  printHello();
  printf(" ");
  printWorld();
  printf("!\n");
  
  return 0;
}