#include <stdio.h>
#include "hello.h"

void printHello() {
  printf(HELLO_STR);
}