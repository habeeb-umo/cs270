#include <stdio.h>
#include "world.h"

void printWorld() {
  printf(WORLD_STR);
}