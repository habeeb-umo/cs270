#define WORLD_STR "World"

void printWorld();